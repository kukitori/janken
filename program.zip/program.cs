using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Sample101{
	class Program{
		static void Main(string[] args){
			int PersonA,PersonB;
			string[] hands = new string[]{"���[","���傫","�ρ["};
			Random cRandom = new System.Random();
			
			PersonA =cRandom.Next(2); 
				PersonB =cRandom.Next(2);
			
			Console.WriteLine("�W�����P��");
			Console.WriteLine("A={0},B={1}",hands[PersonA],hands[PersonB]);
			Console.WriteLine(hantei(PersonA,PersonB));
		}
		static string hantei(int PersonA, int PersonB){
			if(PersonA==PersonB){
				return "������";
			}else if(PersonA==2){
				if(PersonB==0){
	 				return "A�̏���";
				}else{
	 				return "B�̏���";
				}
			}else if(PersonA<PersonB){
				return "A�̏���";
			}else{
				return "B�̏���";
			}
		}
	}
}
